<!-- _navbar.md -->

* [Mineflayer](https://mineflayer.prismarine.js.org/#/)